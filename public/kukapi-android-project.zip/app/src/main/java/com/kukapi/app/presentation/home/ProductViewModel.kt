package com.kukapi.app.presentation.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kukapi.app.domain.model.ApiDiagnosticInfo
import com.kukapi.app.domain.model.Product
import com.kukapi.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface ProductUiState {
    data class Loading(val message: String = "Connecting to Shopify Storefront...") : ProductUiState
    data class Success(
        val products: List<Product>,
        val totalProductsCount: Int,
        val diagnostic: ApiDiagnosticInfo
    ) : ProductUiState
    data class Empty(
        val message: String = "No products found in Shopify store",
        val diagnostic: ApiDiagnosticInfo? = null
    ) : ProductUiState
    data class Error(
        val title: String = "Network Error",
        val message: String,
        val diagnostic: ApiDiagnosticInfo? = null,
        val canRetry: Boolean = true
    ) : ProductUiState
}

class ProductViewModel(
    private val repository: ProductRepository = ProductRepository()
) : ViewModel() {

    companion object {
        private const val TAG = "KUKAPI_VIEWMODEL"
    }

    private val _uiState = MutableStateFlow<ProductUiState>(ProductUiState.Loading())
    val uiState: StateFlow<ProductUiState> = _uiState.asStateFlow()

    private val _showDiagnostic = MutableStateFlow(false)
    val showDiagnostic: StateFlow<Boolean> = _showDiagnostic.asStateFlow()

    private val _latestDiagnostic = MutableStateFlow<ApiDiagnosticInfo?>(null)
    val latestDiagnostic: StateFlow<ApiDiagnosticInfo?> = _latestDiagnostic.asStateFlow()

    private var allProducts: List<Product> = emptyList()
    private var selectedCategory: String = "all"

    init {
        loadProducts()
    }

    fun toggleDiagnostic(show: Boolean? = null) {
        _showDiagnostic.value = show ?: !_showDiagnostic.value
    }

    fun loadProducts(refresh: Boolean = false) {
        viewModelScope.launch {
            _uiState.value = ProductUiState.Loading(if (refresh) "Refreshing Shopify products..." else "Loading products from Shopify...")
            Log.i(TAG, "[VIEWMODEL LOAD START] (refresh=$refresh)")

            val result = repository.getLiveCatalog()

            result.fold(
                onSuccess = { response ->
                    allProducts = response.products
                    _latestDiagnostic.value = response.diagnostic

                    Log.i("KUKAPI_PIPELINE", "[VIEWMODEL] products = ${response.products.size}")

                    if (response.products.isEmpty()) {
                        Log.w(TAG, "[VIEWMODEL EMPTY] 0 products returned")
                        _uiState.value = ProductUiState.Empty(
                            message = "No products found in Kukapi Shopify Store",
                            diagnostic = response.diagnostic
                        )
                    } else {
                        Log.i(TAG, "[VIEWMODEL SUCCESS] Loaded ${response.products.size} real products")
                        val filtered = filterList(response.products, selectedCategory)
                        _uiState.value = ProductUiState.Success(
                            products = filtered,
                            totalProductsCount = response.products.size,
                            diagnostic = response.diagnostic
                        )
                    }
                },
                onFailure = { error ->
                    val errorDescription = error.localizedMessage ?: error.message ?: "Failed to connect to Shopify API"
                    Log.e(TAG, "[VIEWMODEL ERROR] $errorDescription", error)
                    
                    val fallbackDiag = ApiDiagnosticInfo(
                        apiUrl = "https://kukapi.myshopify.com/api/2024-01/graphql.json",
                        httpStatus = if (errorDescription.contains("401")) 401 else 0,
                        apiError = errorDescription,
                        productCount = 0,
                        firstProductTitle = "None",
                        firstProductImageUrl = "None"
                    )
                    _latestDiagnostic.value = fallbackDiag

                    _uiState.value = ProductUiState.Error(
                        title = "Shopify API Error",
                        message = errorDescription,
                        diagnostic = fallbackDiag,
                        canRetry = true
                    )
                }
            )
        }
    }

    fun selectCategory(category: String) {
        selectedCategory = category
        Log.d(TAG, "[CATEGORY SELECTED] $category")
        if (allProducts.isNotEmpty()) {
            val filtered = filterList(allProducts, category)
            val diag = _latestDiagnostic.value ?: ApiDiagnosticInfo()
            if (filtered.isEmpty()) {
                _uiState.value = ProductUiState.Empty(
                    message = "No products found in category '$category'",
                    diagnostic = diag
                )
            } else {
                _uiState.value = ProductUiState.Success(
                    products = filtered,
                    totalProductsCount = allProducts.size,
                    diagnostic = diag
                )
            }
        }
    }

    private fun filterList(products: List<Product>, cat: String): List<Product> {
        if (cat == "all" || cat.isBlank()) return products
        return products.filter { 
            it.category.contains(cat, ignoreCase = true) || 
            it.title.contains(cat, ignoreCase = true)
        }
    }
}
