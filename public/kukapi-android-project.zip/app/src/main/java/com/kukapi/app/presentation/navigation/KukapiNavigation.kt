package com.kukapi.app.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Shop : Screen("shop", "Shop", Icons.Default.ShoppingBag)
    object Search : Screen("search", "Search", Icons.Default.Search)
    object Wishlist : Screen("wishlist", "Wishlist", Icons.Default.Favorite)
    object Account : Screen("account", "Account", Icons.Default.Person)
    object ProductDetail : Screen("product_detail/{productId}", "Product Details", Icons.Default.ShoppingBag) {
        fun createRoute(productId: String): String {
            val encodedId = java.net.URLEncoder.encode(productId, "UTF-8")
            return "product_detail/$encodedId"
        }
    }
}

val bottomNavScreens = listOf(
    Screen.Home,
    Screen.Shop,
    Screen.Search,
    Screen.Wishlist,
    Screen.Account
)
