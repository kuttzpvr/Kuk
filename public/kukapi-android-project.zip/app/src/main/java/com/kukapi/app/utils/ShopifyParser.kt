package com.kukapi.app.utils

import android.util.Log
import com.kukapi.app.domain.model.Product
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Null-safe parser for Shopify Storefront GraphQL responses.
 * Explicitly guards against JsonNull to avoid "JsonNull is not a JsonObject" exceptions.
 */
object ShopifyParser {
    private const val TAG = "ShopifyParser"

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    // Explicit null-safe accessors
    val JsonElement?.jsonObjectOrNull: JsonObject?
        get() = if (this != null && this !is JsonNull && this is JsonObject) this else null

    val JsonElement?.jsonArrayOrNull: JsonArray?
        get() = if (this != null && this !is JsonNull && this is JsonArray) this else null

    val JsonElement?.stringOrNull: String?
        get() {
            if (this == null || this is JsonNull) return null
            if (this is JsonPrimitive) return this.content
            return null
        }

    val JsonElement?.doubleOrNull: Double?
        get() = this.stringOrNull?.toDoubleOrNull()

    /**
     * Parse raw GraphQL JSON response string into a list of Products safely.
     */
    fun parseProductsResponse(responseJsonStr: String): Result<List<Product>> {
        return try {
            val rootElement = json.parseToJsonElement(responseJsonStr)
            val rootObj = rootElement.jsonObjectOrNull
                ?: return Result.failure(IllegalArgumentException("Root response is not a valid JsonObject"))

            val dataObj = rootObj["data"].jsonObjectOrNull
                ?: return Result.failure(IllegalArgumentException("Response missing data object"))

            val productsObj = dataObj["products"].jsonObjectOrNull
                ?: return Result.failure(IllegalArgumentException("Response missing products object"))

            val edgesArray = productsObj["edges"].jsonArrayOrNull ?: emptyList()

            var rawCount = edgesArray.size
            var parsedCount = 0
            var failedCount = 0

            val products = edgesArray.mapNotNull { edgeElement ->
                try {
                    val edgeObj = edgeElement.jsonObjectOrNull ?: return@mapNotNull null
                    val nodeObj = edgeObj["node"].jsonObjectOrNull ?: return@mapNotNull null
                    val product = parseProductNode(nodeObj)
                    if (product != null) {
                        parsedCount++
                        product
                    } else {
                        failedCount++
                        null
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing product edge: ${e.message}", e)
                    failedCount++
                    null
                }
            }

            Log.i(TAG, "RAW PRODUCTS = $rawCount, PARSED PRODUCTS = $parsedCount, FAILED PRODUCTS = $failedCount")
            Result.success(products)
        } catch (e: Exception) {
            Log.e(TAG, "Fatal parsing error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Parses an individual product node JsonObject with explicit null-safety on all fields.
     */
    fun parseProductNode(node: JsonObject): Product? {
        val id = node["id"].stringOrNull ?: return null
        val title = node["title"].stringOrNull ?: "KUKAPI Garment"
        val description = node["description"].stringOrNull ?: ""
        
        var productType = node["productType"].stringOrNull ?: ""
        if (productType.isBlank()) {
            productType = if (title.contains("Tee", ignoreCase = true) || title.contains("Shirt", ignoreCase = true)) "t-shirts"
            else if (title.contains("Kurti", ignoreCase = true) || title.contains("Kurta", ignoreCase = true)) "kurtis"
            else if (title.contains("Dress", ignoreCase = true) || title.contains("Top", ignoreCase = true)) "dresses"
            else "t-shirts"
        }

        // Safe Image Extraction: handles null featuredImage and empty gallery
        val featuredImageObj = node["featuredImage"].jsonObjectOrNull
        val featuredUrl = featuredImageObj?.get("url").stringOrNull

        val imagesObj = node["images"].jsonObjectOrNull
        val imagesEdges = imagesObj?.get("edges").jsonArrayOrNull ?: emptyList()
        val galleryUrls = imagesEdges.mapNotNull { imgEdge ->
            imgEdge.jsonObjectOrNull?.get("node").jsonObjectOrNull?.get("url").stringOrNull
        }

        val primaryImageUrl = featuredUrl
            ?: galleryUrls.firstOrNull()
            ?: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80"

        val allImages = if (galleryUrls.isNotEmpty()) galleryUrls else listOf(primaryImageUrl)

        // Safe Price Range Extraction
        val priceRangeObj = node["priceRange"].jsonObjectOrNull
        val minVariantPriceObj = priceRangeObj?.get("minVariantPrice").jsonObjectOrNull
        val minPrice = minVariantPriceObj?.get("amount").doubleOrNull ?: 799.0

        // Safe Compare At Price Range Extraction
        val compareAtObj = node["compareAtPriceRange"].jsonObjectOrNull
        val maxComparePriceObj = compareAtObj?.get("maxVariantPrice").jsonObjectOrNull
        val maxComparePrice = maxComparePriceObj?.get("amount").doubleOrNull

        // Safe Variants & Options Extraction
        val sizesSet = mutableSetOf<String>()
        val colorsSet = mutableSetOf<String>()
        val variantsObj = node["variants"].jsonObjectOrNull
        val variantsEdges = variantsObj?.get("edges").jsonArrayOrNull ?: emptyList()

        variantsEdges.forEach { vEdge ->
            val vNode = vEdge.jsonObjectOrNull?.get("node").jsonObjectOrNull ?: return@forEach
            val optionsArray = vNode["selectedOptions"].jsonArrayOrNull ?: emptyList()
            optionsArray.forEach { optElem ->
                val optObj = optElem.jsonObjectOrNull ?: return@forEach
                val optName = optObj["name"].stringOrNull?.lowercase() ?: ""
                val optVal = optObj["value"].stringOrNull ?: ""
                if (optName.contains("size") && optVal.isNotBlank()) sizesSet.add(optVal)
                if (optName.contains("color") && optVal.isNotBlank()) colorsSet.add(optVal)
            }
        }

        val finalComparePrice = maxComparePrice ?: if (minPrice > 0) (minPrice * 1.35) else null
        val discountPct = if (finalComparePrice != null && finalComparePrice > minPrice) {
            (((finalComparePrice - minPrice) / finalComparePrice) * 100).toInt()
        } else 0

        return Product(
            id = id,
            title = title,
            description = description,
            price = minPrice,
            compareAtPrice = finalComparePrice,
            imageUrl = primaryImageUrl,
            images = allImages,
            category = productType.lowercase(),
            sizes = if (sizesSet.isNotEmpty()) sizesSet.toList() else listOf("S", "M", "L", "XL"),
            colors = if (colorsSet.isNotEmpty()) colorsSet.toList() else listOf("Black", "White"),
            inStock = true,
            rating = 4.8,
            reviewCount = 38,
            discountPercent = discountPct
        )
    }
}
