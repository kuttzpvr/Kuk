package com.kukapi.app.presentation.account

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kukapi.app.core.designsystem.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    onOpenWishlist: () -> Unit,
    onOpenDiagnostics: () -> Unit
) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "MY ACCOUNT",
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp,
                            fontSize = 17.sp,
                            color = KukapiBlack
                        )
                        Text(
                            text = "KUKAPI CLUB MEMBER",
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            fontSize = 9.sp,
                            color = KukapiAmberDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KukapiWhite)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(KukapiZinc50)
                .verticalScroll(scrollState)
        ) {
            // Profile Card Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = KukapiBlack)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(KukapiAmber),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = KukapiBlack,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "KUKAPI Member",
                            color = KukapiWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "kukapi.official@storefront.com",
                            color = KukapiZinc400,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = KukapiZinc800,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "TIER: VIP GOLD",
                                color = KukapiAmber,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Quick Stats Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickStatCard(title = "Orders", value = "0", modifier = Modifier.weight(1f))
                QuickStatCard(title = "Coupons", value = "2 Active", modifier = Modifier.weight(1f))
                QuickStatCard(title = "Points", value = "450", modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Menu Section: Shopping & Account
            Text(
                text = "ACCOUNT PREFERENCES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = KukapiZinc500,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KukapiWhite)
            ) {
                Column {
                    AccountMenuItem(icon = Icons.Default.ShoppingBag, title = "My Orders", subtitle = "Track and view past purchases")
                    HorizontalDivider(color = KukapiZinc100, modifier = Modifier.padding(horizontal = 16.dp))
                    AccountMenuItem(icon = Icons.Default.Favorite, title = "Wishlist", subtitle = "View saved favorites", onClick = onOpenWishlist)
                    HorizontalDivider(color = KukapiZinc100, modifier = Modifier.padding(horizontal = 16.dp))
                    AccountMenuItem(icon = Icons.Default.LocationOn, title = "Saved Addresses", subtitle = "Manage shipping addresses")
                    HorizontalDivider(color = KukapiZinc100, modifier = Modifier.padding(horizontal = 16.dp))
                    AccountMenuItem(icon = Icons.Default.CreditCard, title = "Payment Methods", subtitle = "UPI, Cards & Net Banking")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Menu Section: Store & Developer Diagnostics
            Text(
                text = "STORE & SUPPORT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = KukapiZinc500,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KukapiWhite)
            ) {
                Column {
                    AccountMenuItem(
                        icon = Icons.Default.BugReport,
                        title = "Shopify API Diagnostics",
                        subtitle = "Inspect live GraphQL connection & stats",
                        onClick = onOpenDiagnostics
                    )
                    HorizontalDivider(color = KukapiZinc100, modifier = Modifier.padding(horizontal = 16.dp))
                    AccountMenuItem(icon = Icons.Default.HelpOutline, title = "Customer Support", subtitle = "24/7 help via WhatsApp & Email")
                    HorizontalDivider(color = KukapiZinc100, modifier = Modifier.padding(horizontal = 16.dp))
                    AccountMenuItem(icon = Icons.Default.Security, title = "Privacy Policy & Terms", subtitle = "Official KUKAPI terms")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // App Version Footer
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "KUKAPI Android App v1.0.0",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = KukapiZinc400
                )
                Text(
                    text = "Connected to kukapi.myshopify.com",
                    fontSize = 10.sp,
                    color = KukapiZinc400
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun QuickStatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = KukapiWhite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, fontWeight = FontWeight.Black, fontSize = 15.sp, color = KukapiBlack)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = title, fontSize = 11.sp, color = KukapiZinc500)
        }
    }
}

@Composable
fun AccountMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = KukapiZinc700,
            modifier = Modifier.size(22.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = KukapiZinc900)
            Text(text = subtitle, fontSize = 11.sp, color = KukapiZinc500)
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = KukapiZinc400,
            modifier = Modifier.size(14.dp)
        )
    }
}
