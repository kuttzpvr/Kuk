package com.kukapi.app.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class Product(
    val id: String,
    val title: String,
    val description: String = "",
    val price: Double,
    val compareAtPrice: Double? = null,
    val imageUrl: String,
    val images: List<String> = emptyList(),
    val category: String = "Apparel",
    val sizes: List<String> = listOf("S", "M", "L", "XL"),
    val colors: List<String> = listOf("Black", "Off-White"),
    val inStock: Boolean = true,
    val rating: Double = 4.8,
    val reviewCount: Int = 24,
    val discountPercent: Int = 0
)

@Serializable
data class CartItem(
    val id: String,
    val product: Product,
    val selectedSize: String,
    val selectedColor: String,
    val quantity: Int,
    val price: Double
)

@Serializable
data class CustomerSession(
    val accessToken: String,
    val expiresAt: String,
    val email: String,
    val firstName: String,
    val lastName: String
)

@Serializable
data class OrderItem(
    val title: String,
    val quantity: Int,
    val price: Double,
    val imageUrl: String,
    val variantTitle: String? = null
)

@Serializable
data class CustomerOrder(
    val id: String,
    val orderNumber: String,
    val processedAt: String,
    val totalPrice: Double,
    val financialStatus: String,
    val fulfillmentStatus: String,
    val items: List<OrderItem> = emptyList()
)
