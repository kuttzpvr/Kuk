package com.kukapi.app.presentation.shop

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kukapi.app.core.designsystem.*
import com.kukapi.app.domain.model.Product
import com.kukapi.app.presentation.home.ProductCard
import com.kukapi.app.presentation.home.ProductUiState
import com.kukapi.app.presentation.home.ProductViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(
    viewModel: ProductViewModel,
    onProductClick: (Product) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedCategory by remember { mutableStateOf("all") }
    var sortBy by remember { mutableStateOf("featured") } // featured, price_low, price_high

    val categories = listOf(
        "all" to "All Items",
        "t-shirt" to "T-Shirts",
        "oversized" to "Oversized",
        "tee" to "Tees",
        "kurti" to "Ethnic",
        "top" to "Tops"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "SHOP CATALOG",
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp,
                            fontSize = 17.sp,
                            color = KukapiBlack
                        )
                        Text(
                            text = "FULL COLLECTION",
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            fontSize = 9.sp,
                            color = KukapiZinc500
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.loadProducts(refresh = true) }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = KukapiZinc900
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KukapiWhite)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(KukapiZinc50)
        ) {
            when (val state = uiState) {
                is ProductUiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = KukapiBlack)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(state.message, color = KukapiZinc500, fontSize = 13.sp)
                    }
                }

                is ProductUiState.Empty -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = KukapiZinc400, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(state.message, fontWeight = FontWeight.Bold, color = KukapiZinc900)
                    }
                }

                is ProductUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Unable to load shop catalog", fontWeight = FontWeight.Bold, color = KukapiZinc900)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { viewModel.loadProducts(refresh = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = KukapiBlack)
                        ) {
                            Text("Retry")
                        }
                    }
                }

                is ProductUiState.Success -> {
                    val sortedProducts = remember(state.products, sortBy) {
                        when (sortBy) {
                            "price_low" -> state.products.sortedBy { it.price }
                            "price_high" -> state.products.sortedByDescending { it.price }
                            else -> state.products
                        }
                    }

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Category Chips Header
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                categories.forEach { (catKey, catLabel) ->
                                    val isSelected = selectedCategory == catKey
                                    Surface(
                                        shape = RoundedCornerShape(20.dp),
                                        color = if (isSelected) KukapiBlack else KukapiWhite,
                                        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, KukapiZinc200),
                                        modifier = Modifier.clickable {
                                            selectedCategory = catKey
                                            viewModel.selectCategory(catKey)
                                        }
                                    ) {
                                        Text(
                                            text = catLabel,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) KukapiWhite else KukapiZinc900,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Product count & sort bar
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${sortedProducts.size} STYLES AVAILABLE",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = KukapiZinc500,
                                    letterSpacing = 1.sp
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    AssistChip(
                                        onClick = {
                                            sortBy = if (sortBy == "price_low") "price_high" else if (sortBy == "price_high") "featured" else "price_low"
                                        },
                                        label = {
                                            Text(
                                                text = when (sortBy) {
                                                    "price_low" -> "Price: Low to High"
                                                    "price_high" -> "Price: High to Low"
                                                    else -> "Sort: Featured"
                                                },
                                                fontSize = 10.sp
                                            )
                                        }
                                    )
                                }
                            }
                        }

                        // Product Items
                        items(sortedProducts, key = { it.id }) { product ->
                            ProductCard(
                                product = product,
                                onClick = { onProductClick(product) }
                            )
                        }
                    }
                }
            }
        }
    }
}
