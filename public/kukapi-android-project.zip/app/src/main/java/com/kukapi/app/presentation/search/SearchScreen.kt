package com.kukapi.app.presentation.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kukapi.app.core.designsystem.*
import com.kukapi.app.domain.model.Product
import com.kukapi.app.presentation.home.ProductCard
import com.kukapi.app.presentation.home.ProductUiState
import com.kukapi.app.presentation.home.ProductViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: ProductViewModel,
    onProductClick: (Product) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val popularTags = listOf("Oversized", "T-Shirt", "Riders", "Black", "Kurti", "Cotton")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search 34 Shopify styles...", fontSize = 13.sp, color = KukapiZinc400) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = KukapiZinc500, modifier = Modifier.size(20.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = KukapiZinc500, modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = KukapiZinc100,
                            unfocusedContainerColor = KukapiZinc100,
                            focusedBorderColor = KukapiBlack,
                            unfocusedBorderColor = KukapiZinc200
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(end = 12.dp)
                            .height(50.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KukapiWhite)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(KukapiZinc50)
        ) {
            when (val state = uiState) {
                is ProductUiState.Success -> {
                    val filteredProducts = remember(state.products, searchQuery) {
                        if (searchQuery.isBlank()) {
                            state.products
                        } else {
                            val q = searchQuery.trim().lowercase()
                            state.products.filter {
                                it.title.lowercase().contains(q) ||
                                it.category.lowercase().contains(q) ||
                                it.tags.any { tag -> tag.lowercase().contains(q) } ||
                                it.description.lowercase().contains(q)
                            }
                        }
                    }

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Quick filter suggestions
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                            Column(modifier = Modifier.padding(bottom = 6.dp)) {
                                Text(
                                    text = "POPULAR SEARCHES",
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    fontSize = 10.sp,
                                    color = KukapiZinc500
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(popularTags) { tag ->
                                        Surface(
                                            shape = RoundedCornerShape(16.dp),
                                            color = if (searchQuery.equals(tag, ignoreCase = true)) KukapiBlack else KukapiWhite,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, KukapiZinc200),
                                            modifier = Modifier.clickable { searchQuery = tag }
                                        ) {
                                            Text(
                                                text = tag,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = if (searchQuery.equals(tag, ignoreCase = true)) KukapiWhite else KukapiZinc800,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Search result summary
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (searchQuery.isBlank()) "ALL PRODUCTS (${filteredProducts.size})" else "SEARCH RESULTS (${filteredProducts.size})",
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp,
                                    fontSize = 12.sp,
                                    color = KukapiZinc900
                                )
                            }
                        }

                        if (filteredProducts.isEmpty()) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(40.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = KukapiZinc400, modifier = Modifier.size(44.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No matches found for '$searchQuery'", fontWeight = FontWeight.Bold, color = KukapiZinc800)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Try checking for typos or searching by broad keywords like 't-shirt' or 'oversized'.", color = KukapiZinc500, fontSize = 12.sp)
                                }
                            }
                        } else {
                            items(filteredProducts, key = { it.id }) { product ->
                                ProductCard(
                                    product = product,
                                    onClick = { onProductClick(product) }
                                )
                            }
                        }
                    }
                }

                is ProductUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = KukapiBlack)
                    }
                }

                else -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Please reload products from Home screen", color = KukapiZinc600)
                    }
                }
            }
        }
    }
}
