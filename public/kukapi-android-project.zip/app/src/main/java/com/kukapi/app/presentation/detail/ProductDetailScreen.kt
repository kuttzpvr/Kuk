package com.kukapi.app.presentation.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.kukapi.app.core.designsystem.*
import com.kukapi.app.domain.model.Product

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    product: Product,
    onBack: () -> Unit,
    isWishlisted: Boolean = false,
    onToggleWishlist: (Product) -> Unit = {}
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var selectedImageIndex by remember { mutableStateOf(0) }
    var selectedSize by remember { mutableStateOf(product.sizes.firstOrNull() ?: "M") }
    var selectedColor by remember { mutableStateOf(product.colors.firstOrNull() ?: "Black") }
    var quantity by remember { mutableStateOf(1) }
    var showAddedSnackbar by remember { mutableStateOf(false) }

    val imagesList = if (product.images.isNotEmpty()) product.images else listOf(product.imageUrl)
    val currentImage = imagesList.getOrElse(selectedImageIndex) { product.imageUrl }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "PRODUCT DETAILS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        letterSpacing = 1.5.sp,
                        color = KukapiBlack
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = KukapiBlack
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { onToggleWishlist(product) }) {
                        Icon(
                            imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Wishlist",
                            tint = if (isWishlisted) Color(0xFFEF4444) else KukapiZinc700
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KukapiWhite)
            )
        },
        bottomBar = {
            Surface(
                color = KukapiWhite,
                shadowElevation = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Total Price",
                            fontSize = 11.sp,
                            color = KukapiZinc500
                        )
                        Text(
                            text = "₹${(product.price * quantity).toInt()}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = KukapiBlack
                        )
                    }

                    Button(
                        onClick = { showAddedSnackbar = true },
                        colors = ButtonDefaults.buttonColors(containerColor = KukapiBlack),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(2f).height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (showAddedSnackbar) "ADDED TO CART!" else "ADD TO CART",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(KukapiZinc50)
                .verticalScroll(scrollState)
        ) {
            // Main Featured Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .background(KukapiZinc100)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(currentImage)
                        .crossfade(true)
                        .build(),
                    contentDescription = product.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                if (product.discountPercent > 0) {
                    Surface(
                        color = KukapiAmber,
                        shape = RoundedCornerShape(bottomEnd = 8.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "${product.discountPercent}% OFF",
                            color = KukapiBlack,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // Image Gallery Thumbnails
            if (imagesList.size > 1) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(imagesList.indices.toList()) { index ->
                        val isSelected = selectedImageIndex == index
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) KukapiBlack else KukapiZinc200,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedImageIndex = index }
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(imagesList[index])
                                    .crossfade(true)
                                    .build(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }

            // Details Container
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Title and Category
                Text(
                    text = product.category.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = KukapiAmberDark,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = product.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = KukapiZinc900,
                    lineHeight = 26.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Price Section
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "₹${product.price.toInt()}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = KukapiBlack
                    )

                    product.compareAtPrice?.let { comp ->
                        if (comp > product.price) {
                            Text(
                                text = "₹${comp.toInt()}",
                                fontSize = 15.sp,
                                color = KukapiZinc400,
                                style = androidx.compose.ui.text.TextStyle(textDecoration = TextDecoration.LineThrough)
                            )
                        }
                    }

                    Surface(
                        color = Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "Inclusive of all taxes",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF166534),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = KukapiZinc200)
                Spacer(modifier = Modifier.height(16.dp))

                // Size Selector
                Text(
                    text = "SELECT SIZE",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = KukapiZinc900
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    product.sizes.forEach { size ->
                        val isSelected = selectedSize == size
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) KukapiBlack else KukapiWhite,
                            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, KukapiZinc300),
                            modifier = Modifier
                                .clickable { selectedSize = size }
                                .width(48.dp)
                                .height(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = size,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) KukapiWhite else KukapiZinc900,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Color Selector
                Text(
                    text = "COLOR: $selectedColor",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = KukapiZinc900
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    product.colors.forEach { color ->
                        val isSelected = selectedColor == color
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) KukapiBlack else KukapiWhite,
                            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, KukapiZinc300),
                            modifier = Modifier.clickable { selectedColor = color }
                        ) {
                            Text(
                                text = color,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) KukapiWhite else KukapiZinc900,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = KukapiZinc200)
                Spacer(modifier = Modifier.height(16.dp))

                // Product Description
                Text(
                    text = "DESCRIPTION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = KukapiZinc900
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (product.description.isNotBlank()) product.description else "Premium 100% combed cotton streetwear apparel engineered for all-day comfort and long-lasting quality.",
                    fontSize = 13.sp,
                    color = KukapiZinc600,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
