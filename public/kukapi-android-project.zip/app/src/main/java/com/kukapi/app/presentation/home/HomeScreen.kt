package com.kukapi.app.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.kukapi.app.core.designsystem.*
import com.kukapi.app.domain.model.ApiDiagnosticInfo
import com.kukapi.app.domain.model.Product

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: ProductViewModel,
    onProductClick: (Product) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val showDiagnostic by viewModel.showDiagnostic.collectAsState()
    val latestDiagnostic by viewModel.latestDiagnostic.collectAsState()

    var selectedCategory by remember { mutableStateOf("all") }

    val categories = listOf(
        "all" to "All",
        "t-shirt" to "T-Shirts",
        "oversized" to "Oversized",
        "tee" to "Tees",
        "kurti" to "Ethnic",
        "top" to "Tops"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "KUKAPI",
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 4.sp,
                            fontSize = 20.sp,
                            color = KukapiBlack
                        )
                        Text(
                            text = "OFFICIAL STOREFRONT",
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.5.sp,
                            fontSize = 8.sp,
                            color = KukapiZinc500
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleDiagnostic() }) {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = "API Diagnostic",
                            tint = if (showDiagnostic) KukapiAmber else KukapiZinc600
                        )
                    }
                    IconButton(onClick = { viewModel.loadProducts(refresh = true) }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Catalog",
                            tint = KukapiZinc900
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = KukapiWhite
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(KukapiZinc50)
        ) {
            if (showDiagnostic) {
                // Dedicated Diagnostic Screen View
                DiagnosticScreen(
                    diagnostic = latestDiagnostic ?: ApiDiagnosticInfo(),
                    onClose = { viewModel.toggleDiagnostic(false) },
                    onReTest = { viewModel.loadProducts(refresh = true) }
                )
            } else {
                when (val state = uiState) {
                    is ProductUiState.Loading -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = KukapiBlack, strokeWidth = 3.dp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = state.message,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = KukapiZinc500
                            )
                        }
                    }

                    is ProductUiState.Empty -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = null,
                                tint = KukapiZinc400,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = state.message,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = KukapiZinc900,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.loadProducts(refresh = true) },
                                    colors = ButtonDefaults.buttonColors(containerColor = KukapiBlack),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Reload Products")
                                }
                                OutlinedButton(
                                    onClick = { viewModel.toggleDiagnostic(true) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("View Diagnostics")
                                }
                            }
                        }
                    }

                    is ProductUiState.Error -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = state.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = KukapiZinc900
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = state.message,
                                fontSize = 12.sp,
                                color = KukapiZinc500,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (state.canRetry) {
                                    Button(
                                        onClick = { viewModel.loadProducts(refresh = true) },
                                        colors = ButtonDefaults.buttonColors(containerColor = KukapiBlack),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Retry Connection")
                                    }
                                }
                                OutlinedButton(
                                    onClick = { viewModel.toggleDiagnostic(true) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Show Diagnostics")
                                }
                            }
                        }
                    }

                    is ProductUiState.Success -> {
                        android.util.Log.i("KUKAPI_PIPELINE", "[UI] products received = ${state.products.size}")
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            contentPadding = PaddingValues(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Hero Banner Header
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = KukapiBlack)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(20.dp),
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = "FLASH SALE LIVE",
                                            color = KukapiAmber,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.sp
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "FLAT 40% OFF",
                                            color = KukapiWhite,
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 1.sp
                                        )
                                        Text(
                                            text = "Use code KUKAPI40 at checkout",
                                            color = KukapiZinc400,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            // Category Filter Chips
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    categories.forEach { (catKey, catLabel) ->
                                        val isSelected = selectedCategory == catKey
                                        Surface(
                                            shape = RoundedCornerShape(20.dp),
                                            color = if (isSelected) KukapiBlack else KukapiWhite,
                                            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, KukapiZinc200),
                                            modifier = Modifier.clickable {
                                                selectedCategory = catKey
                                                viewModel.selectCategory(catKey)
                                            }
                                        ) {
                                            Text(
                                                text = catLabel,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                color = if (isSelected) KukapiWhite else KukapiZinc900,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Section Title & Count Badge
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "TRENDING DROPS",
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 2.sp,
                                        fontSize = 14.sp,
                                        color = KukapiZinc900
                                    )
                                    Text(
                                        text = "${state.products.size} REAL PRODUCTS",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = KukapiZinc500,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }

                            // Real Live Product Cards
                            items(state.products, key = { it.id }) { product ->
                                ProductCard(
                                    product = product,
                                    onClick = { onProductClick(product) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiagnosticScreen(
    diagnostic: ApiDiagnosticInfo,
    onClose: () -> Unit,
    onReTest: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SHOPIFY API DIAGNOSTICS",
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    DiagnosticRow(
                        label = "API URL:",
                        value = diagnostic.apiUrl,
                        highlight = false
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DiagnosticRow(
                        label = "HTTP STATUS:",
                        value = if (diagnostic.httpStatus > 0) "${diagnostic.httpStatus} OK" else "NOT CONNECTED",
                        highlight = diagnostic.httpStatus == 200
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DiagnosticRow(
                        label = "API ERROR:",
                        value = diagnostic.apiError ?: "None (Healthy)",
                        highlight = diagnostic.apiError == null
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DiagnosticRow(
                        label = "PRODUCT COUNT:",
                        value = "${diagnostic.productCount} Live Products",
                        highlight = diagnostic.productCount > 0
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DiagnosticRow(
                        label = "FIRST PRODUCT TITLE:",
                        value = diagnostic.firstProductTitle,
                        highlight = false
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DiagnosticRow(
                        label = "FIRST PRODUCT IMAGE URL:",
                        value = diagnostic.firstProductImageUrl,
                        highlight = false
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onReTest,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("TEST LIVE API REQUEST NOW", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Text("Back to Storefront")
            }
        }
    }
}

@Composable
fun DiagnosticRow(
    label: String,
    value: String,
    highlight: Boolean
) {
    Column {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF94A3B8)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (highlight) Color(0xFF4ADE80) else Color(0xFFF1F5F9),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ProductCard(
    product: Product,
    onClick: () -> Unit = {}
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = KukapiWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(KukapiZinc100)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(product.imageUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = product.title,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                    contentScale = ContentScale.Crop
                )

                if (product.discountPercent > 0) {
                    Surface(
                        color = KukapiAmber,
                        shape = RoundedCornerShape(bottomEnd = 8.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "${product.discountPercent}% OFF",
                            color = KukapiBlack,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = product.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = KukapiZinc900,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "₹${product.price.toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = KukapiBlack
                    )
                    product.compareAtPrice?.let { comparePrice ->
                        if (comparePrice > product.price) {
                            Text(
                                text = "₹${comparePrice.toInt()}",
                                color = KukapiZinc400,
                                fontSize = 11.sp,
                                style = androidx.compose.ui.text.TextStyle(
                                    textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
